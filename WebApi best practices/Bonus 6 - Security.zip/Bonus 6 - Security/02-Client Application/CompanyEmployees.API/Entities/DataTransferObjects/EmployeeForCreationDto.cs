﻿using System.ComponentModel.DataAnnotations;

namespace Entities.DataTransferObjects
{
    public class EmployeeForCreationDto : EmployeeForManipulationDto
    {  
    }
}
